# Padho Aur Kamao — Real Integration Ready

## Included
- Responsive frontend
- Live-style earnings dashboard fed by `/api/earnings`
- Admin page
- Course/affiliate URL management
- Transaction database JSON for starter/demo use
- Webhook endpoint scaffold: `/webhook/affiliate`
- Environment-variable template for secrets

## Run locally
1. Install Node.js.
2. Open this folder in terminal.
3. Run `npm install`
4. Set server-side secrets using `.env`/hosting secret manager.
5. Run `npm start`
6. Open `http://localhost:3000`

## To make earnings REAL
The exact implementation depends on your affiliate network. We need its official API/webhook/reporting documentation and your approved credentials. Do NOT put API secrets in `index.html`.
The webhook code is only a scaffold; production use requires verifying the provider's webhook signature, preventing duplicate events, authenticating admin routes, using a real database, and adding HTTPS.

## Payment
Affiliate course checkout should normally remain on the affiliate provider's official checkout unless your program explicitly permits another flow. A payment gateway is separate from affiliate commission tracking.

## No guaranteed income
Actual earnings depend on traffic, conversions, refunds, program terms, attribution, and approval status.
