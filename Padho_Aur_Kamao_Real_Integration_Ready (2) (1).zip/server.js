const express=require("express"),fs=require("fs"),path=require("path");
const app=express(); app.use(express.json()); app.use(express.static(__dirname));
const DB=path.join(__dirname,"data.json");
function read(){return JSON.parse(fs.readFileSync(DB,"utf8"))}
function write(d){fs.writeFileSync(DB,JSON.stringify(d,null,2))}
app.get("/api/earnings",(req,res)=>{const d=read();let total=d.transactions.filter(x=>x.status!=="rejected").reduce((a,x)=>a+Number(x.commission||0),0);let month=d.transactions.filter(x=>x.date.startsWith(new Date().toISOString().slice(0,7))).reduce((a,x)=>a+Number(x.commission||0),0);res.json({total_earnings:total,month_earnings:month,clicks:d.stats.clicks,conversions:d.transactions.length})});
app.get("/api/transactions",(req,res)=>res.json(read().transactions));
app.post("/api/admin/config",(req,res)=>{let d=read();d.config={...d.config,...req.body};write(d);res.json({message:"Configuration saved. Credentials should be kept in server environment variables."})});
app.post("/api/admin/courses",(req,res)=>{let d=read();d.courses.push({...req.body,id:Date.now()});write(d);res.json({message:"Course saved."})});
app.post("/webhook/affiliate",(req,res)=>{const d=read(); /* IMPORTANT: verify provider signature here before accepting real events. */ if(!req.body||!req.body.commission){return res.status(400).json({error:"Invalid event"})} d.transactions.push({date:new Date().toISOString().slice(0,10),course:req.body.course||"Affiliate Sale",commission:Number(req.body.commission),status:req.body.status||"pending",external_id:req.body.id||""});write(d);res.json({ok:true})});
app.listen(process.env.PORT||3000,()=>console.log("Padho Aur Kamao running on http://localhost:"+(process.env.PORT||3000)));